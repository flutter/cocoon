# Copyright 2024 The Flutter Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

import functions_framework
from google.cloud import firestore
import json
import os
import random
import requests

# Webhook URL is set as ENV var in function settings
DISCORD_WEBHOOK_URL = os.environ['DISCORD_WEBHOOK_URL']
FIRESTORE_PROJECT_NAME = 'flutter-dashboard'
FIRESTORE_DB_NAME = 'flutter-discord-bot'
FIRESTORE_COLLECTION_NAME = "last_state_posted"
FIRESTORE_DOCUMENT_NAME = "flutter_master"

POSITIVES = [
    "Huzzah!",
    "Hip hip hooray!",
    "Yahoo!",
    "Alright!",
    "Heck yeah!",
    "Hot dog!",
    "High five!",
    "Score!",
    "Pow!",
    "Shazam!",
    "Abracadabra!",
    "Bada bing bada boom!",
    "Cowabunga!",
    "Right-o!",
    "Pip pip!",
    "By Jove!",
    "Smashing!",
    "Splendid!",
    "Winner winner chicken dinner!",
    "Nailed it!",
    "Let's get this party started!",
    "Time to celebrate!",
    "Give yourself a pat on the back!",
    "Told you so!",
    "Holy guacamole!",
    "Sweet as pie!",
    "Easy peasy lemon squeezy!",
    "Butter my biscuits!",
    "Sweet!",
    "Peas and carrots!",
    "Onward and upward!",
    "You've got this!",
    "Keep on truckin'!",
    "Chin up!",
    "Don't sweat the small stuff!",
    "Keep shining!",
    "You're a star!",
    "I believe in you!",
    "Never give up!",
    "You're one of a kind!",
    "Yowza!",
    "Booyah!",
    "Beep boop!",
    "Hocus pocus!",
    "Wham bam!",
    "Golly gee whiz!",
    "Well, I'll be!",
    "Bazinga!",
    "Buckle up, buttercup!",
    "Holy mackerel!",
    "Happy dance time!",
    "Let the good times roll!",
    "Today's a good day!",
    "Feeling awesome!",
    "This calls for a fist pump!",
    "Yessss!",
    "Boom shakalaka!",
    "Party time!",
    "Squee!",
    "Fantabulous!",
    "For reals!",
    "Oh snap!",
    "Right on!",
    "Totes amazeballs!",
    "I dig it!",
    "Fo' shizzle!",
]
NEGATIVES = [
    "Aw, man!",
    "Well, this is just peachy.",
    "Well, that's different.",
    "Whoops-a-daisy!",
    "Oh, fiddlesticks!",
    "Meh.",
    "Not my favorite thing.",
    "Could be worse, I suppose.",
    "It happens.",
    "Oh, come on!",
    "You've got to be kidding me.",
    "Could this day get any weirder?",
    "Why me?",
    "Of all the things...",
    "Well, that could've gone better.",
    "Oh well, can't win 'em all.",
    "I'm not even surprised anymore.",
    "Blech!",
    "That's a big nope from me.",
    "Not my cup of tea.",
    "I think I'll stick with what I know.",
    "That's a weird flex, but okay.",
    "That's...a choice.",
    "Drat and double drat!",
    "Pish posh!",
    "Botheration!",
    "Blast and bother!",
    "Well, I never!",
    "Goodness gracious!",
    "My word!",
    "Fiddlesticks and flapjacks!",
    "Well, isn't this fantastic.",
    "Well, this is fun.",
    "Oh, the suspense is killing me.",
    "Ugh.",
    "Argh!",
    "Rats!",
    "Phooey!",
    "Drat!",
    "Yikes!",
    "Oh no!",
    "Bummer.",
    "Darn it!",
    "That stinks!",
    "Oh, bother.",
    "For crying out loud!",
    "Seriously?",
    "Give me a break.",
    "Well, this is awkward.",
    "Of course.",
    "What the heck?",
    "Oh, great.",
    "Not again!",
    "Yuck!",
    "Gross!",
    "Ick!",
    "Ugh, I can't.",
    "Nope.",
    "No way.",
    "That's just wrong.",
    "What a shame.",
    "What a disaster!",
    "This is terrible.",
    "What a nightmare.",
    "This is a joke, right?",
    "Fiddlesticks!",
    "Balderdash!",
    "Poppycock!",
    "Blast!",
    "Confound it!",
    "Zounds!",
    "Gadzooks!",
    "Alas.",
    "Woe is me.",
    "Vexed!", 
    "What a pity.",
    "How unfortunate.",
    "How disappointing.",
]

@functions_framework.http
def hello_http(request):
  """Triggered by HTTP request or scheduled event"""

  # 1. Get response from Flutter Dashboard
  response = requests.get("https://flutter-dashboard.appspot.com/api/public/build-status?branch=master&repo=flutter")

  if response.status_code != 200:
    # Handle API errors if needed
    return "Error getting data from Flutter Dashboard build-status"

  data = json.loads(response.text)
  current_status = data["1"]

  # 2. Get last response from Firestore
  db = firestore.Client(project=FIRESTORE_PROJECT_NAME, database=FIRESTORE_DB_NAME)
  doc_ref = db.collection(FIRESTORE_COLLECTION_NAME).document(FIRESTORE_DOCUMENT_NAME)
  doc = doc_ref.get()

  last_status = None
  if doc.exists:
    if 'status' in doc.to_dict():  # Check for field existence
      last_status = doc.get('status')

  # 3. Update Firestore with the new response
  doc_ref.set({'status': current_status})

  # 4. Compare and send Discord message if different
  if current_status != last_status:
    discord_message = f"Flutter build status changed! New status: {current_status}"
    # Use your Discord library to send the webhook message 
    # Example using simple 'requests' library:
    content = ''
    # 1 is green, 2 is red
    if current_status == 1:
      content = random.choice(POSITIVES) + ' ' + 'The Tree is :green_circle:'
    elif current_status == 2:
      content = random.choice(NEGATIVES) + ' ' + 'The Tree is :red_circle:'
    requests.post(DISCORD_WEBHOOK_URL, data={'content': content})
  else:
    return "Done: skipping posting, tree status has not changed."
  return "Discord bot done" 
